package com.simplilearn.hobbyservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HobbyServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
