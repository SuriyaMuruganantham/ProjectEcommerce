package com.simplilearn.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.simplilearn.entity.Orders;
import com.simplilearn.service.OrderService;

@RestController
public class OrderController {

	@Autowired
	OrderService OrderService;

	@GetMapping("/orders")
	public List<Orders> listOrders() {
		return OrderService.getOrders();
	}

	@GetMapping("/orders/{id}")
	public List<Orders> searchOrdersById(@PathVariable("id") long id) {
		return OrderService.findById(id);
	}

	@PostMapping("/orders")
	public void addOrders(@RequestBody Orders newOrder) {
	 OrderService.save(newOrder);
	}
}

