package com.simplilearn.entity;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Orders {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private long category_id;
	private long quantity;
	public Orders(long quantity) {
		super();
		this.quantity = quantity;
	}
	public long getQuantity() {
		return quantity;
	}
	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}
	private long productid;
	private long user_id;
	public long getId() {
		return id;
	}
	public Orders(long id, long category_id, long productid, long user_id) {
		super();
		this.id = id;
		this.category_id = category_id;
		
		this.productid = productid;
		this.user_id = user_id;
	}
	public Orders() {
		super();
	}

	public void setId(long id) {
		this.id = id;
	}
	public long getCategory_id() {
		return category_id;
	}
	public void setCategory_id(long category_id) {
		this.category_id = category_id;
	}
	
	public long getProductid() {
		return productid;
	}
	public void setProductid(long productid) {
		this.productid = productid;
	}
	public long getUser_id() {
		return user_id;
	}
	public void setUser_id(long user_id) {
		this.user_id = user_id;
	}
}