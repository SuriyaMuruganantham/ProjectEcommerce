package com.simplilearn.service;

import java.util.List;

import com.simplilearn.entity.Orders;

public interface OrderService {
	void save(Orders Orders);
	List<Orders> getOrders();
	List<Orders> findById(long id);
}