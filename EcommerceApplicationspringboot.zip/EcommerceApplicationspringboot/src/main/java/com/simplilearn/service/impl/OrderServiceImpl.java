
	package com.simplilearn.service.impl;

	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;

	import com.simplilearn.entity.Orders;
	import com.simplilearn.repository.OrderRepository;
	import com.simplilearn.service.OrderService;

	@Service
	public class OrderServiceImpl implements OrderService {

		@Autowired
		OrderRepository OrderRepository;

		@Override
		public void save(Orders orders) {
			OrderRepository.save(orders);
		}

		@Override
		public List<Orders> getOrders() {
			return OrderRepository.findAll();
		}

		@Override
		public List<Orders> findById(long id) {
			return OrderRepository.findById(id);
		}
	}

